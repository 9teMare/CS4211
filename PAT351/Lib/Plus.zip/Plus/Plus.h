// Plus.h


#define DllExport   __declspec( dllexport )
extern "C" DllExport int plus(int a, int b);
